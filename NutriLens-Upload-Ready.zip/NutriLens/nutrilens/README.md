# NutriLens — SnackSwap Showdown

A frontend-only React + TypeScript + Vite college project. It does **not** require a backend, database, Prisma, or authentication. Snack records are bundled in `frontend/src/snacks.json`; swap history and challenge progress are saved in this browser's localStorage.

## Requirements
- Node.js 20.19+ or 22.12+ recommended
- npm

## Run locally
From the extracted `nutrilens` project root (the folder containing this README):

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally `http://localhost:5173`). Keep the terminal running while using the site.

## Production build
```bash
npm run build
npm run preview
```

## Included features
- Dashboard and snack collection
- Snack search and category filtering
- Nutrition comparison and alternative recommendations
- Local swap history and weekly challenge
- Manual barcode lookup through Open Food Facts (internet required)
- Responsive layout and subtle motion/hover animations, with reduced-motion accessibility support

## Notes
- No database or backend server is used.
- Barcode lookup requires an internet connection and is manual entry, not camera scanning.
- Nutrition records are illustrative educational estimates unless a record explicitly identifies a verified source. Check product packaging for authoritative values.
- Exercise equivalencies are approximate comparisons, not exercise prescriptions or instructions to compensate for eating.
