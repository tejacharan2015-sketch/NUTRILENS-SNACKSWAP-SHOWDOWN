export default { plugins: { autoprefixer: {} } };
